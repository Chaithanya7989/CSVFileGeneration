﻿using Coravel.Invocable;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using MySql.Data.MySqlClient;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Threading.Tasks;

namespace CSV.CsvGeneration
{
    public class CSVFileGeneration:IInvocable
    {
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<Worker> _logger;
        private readonly IDataReader reader;
        public CSVFileGeneration(IConfiguration iconfiguration, ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger<Worker>();
            _iconfiguration = iconfiguration;
             CsvGeneration();  
        }
        public void CsvGeneration()
        {
            var logpath = _iconfiguration.GetSection("Path_Information").GetSection("LogPath").Value;
            Log.Logger = new LoggerConfiguration().WriteTo.File(logpath).CreateLogger();
            Log.Information("sample information");
            if(1==1)
            {
                var Con = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("MySql_Connection").Value;
                string selectQuery = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("Querystring").Value;
                var table = ReadTable(Con, selectQuery);
                var path = _iconfiguration.GetSection("Path_Information").GetSection("Path").Value;
                ReadTable(Con, selectQuery);
                WriteToFile(table, path, false, ", ");
            }
            if(2==2)
            {
                var Con = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("MySql_Tcp").Value;
                string selectQuery = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("Query_TCP_transition_tcp").Value;
                var table = ReadTable(Con, selectQuery);
                var path = _iconfiguration.GetSection("Path_Information").GetSection("Path_Transition_tcp").Value;
                ReadTable(Con, selectQuery);
                WriteToFile(table, path, false, ", ");  
            }
            if(3==3)
            {
                var Con = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("MySql_Tcp").Value;
                string selectQuery = _iconfiguration.GetSection("MySql_ConnectionString").GetSection("Query_tcp_staging").Value;
                var table = ReadTable(Con, selectQuery);
                var path = _iconfiguration.GetSection("Path_Information").GetSection("Path_transition_tcp_staging").Value;
                ReadTable(Con, selectQuery);
                WriteToFile(table, path, false, ", ");
            }

        }
        public static DataTable ReadTable(string connectionString, string selectQuery)
        {
            var returnValue = new DataTable();
            var conn = new MySqlConnection(connectionString);
            try
            {
                conn.Open();
                var command = new MySqlCommand(selectQuery, conn);
                using (var adapter = new MySqlDataAdapter(command))
                {
                    adapter.Fill(returnValue);
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }
            return returnValue;
        }
        public static void WriteToFile(DataTable dataSource, string fileOutputPath, bool firstRowIsColumnHeader = false, string seperator = ";")
        {
            try
            {
                var sw = new StreamWriter(fileOutputPath, false);
                int icolcount = dataSource.Columns.Count;
                if (!firstRowIsColumnHeader)
                {
                    int data = dataSource.Columns.Count;
                    for (int i = 0; i < data; i++)
                    {
                        sw.Write(dataSource.Columns[i]);
                        if (i < data - 1)
                        sw.Write(seperator);
                    }
                    sw.Write(sw.NewLine);
                }
                foreach (DataRow drow in dataSource.Rows)
                {
                   
                    int data = dataSource.Columns.Count;

                    for (int i = 0; i < data; i++)
                    {
                        if (!Convert.IsDBNull(drow[i]))
                            sw.Write(drow[i].ToString());
                        if (i < data - 1)
                            sw.Write(seperator);
                    }
                   sw.Write(sw.NewLine);
                }
                sw.Close();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
                throw ex;
            }
        }
        public Task Invoke()
        {
            Console.WriteLine("The CSV file Generation has been Scheduled" + DateTime.Now.ToString());
            return Task.CompletedTask;
        }

    }
}

 




