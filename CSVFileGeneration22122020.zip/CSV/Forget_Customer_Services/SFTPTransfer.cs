﻿using Coravel.Invocable;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Threading.Tasks;
using WinSCP;

namespace CSV.CsvGeneration
{
    public class SFTPTransfer: IInvocable
    {
        private readonly IConfiguration _iconfiguration;
        private readonly ILogger<Worker> _logger;
        public SFTPTransfer(IConfiguration iconfiguration, ILoggerFactory loggerFactory, ILogger<Worker> logger)
        {
            _logger = loggerFactory.CreateLogger<Worker>();
            _iconfiguration = iconfiguration;
            _logger = logger;
            SFTP_FileTransfer();
        }

        public Task Invoke()
        {
            Console.WriteLine("The CSV file Generation has been Scheduled" + DateTime.Now.ToString());
            return Task.CompletedTask;
        }

        public void SFTP_FileTransfer()
        {
            try
            {
                var logpath = _iconfiguration.GetSection("FileServerInfo").GetSection("LogPath").Value;
                Log.Logger = new LoggerConfiguration().WriteTo.File(logpath).CreateLogger();
                SessionOptions sessionOptions = new SessionOptions
                {
                    Protocol = Protocol.Sftp,
                    HostName = _iconfiguration.GetSection("FileServerInfo").GetSection("Host").Value,
                    UserName = _iconfiguration.GetSection("FileServerInfo").GetSection("UserName").Value,
                    Password = _iconfiguration.GetSection("FileServerInfo").GetSection("Password").Value,
                    PortNumber = Convert.ToInt32(_iconfiguration.GetSection("FileServerInfo").GetSection("Port").Value),
                    SshHostKeyFingerprint = _iconfiguration.GetSection("FileServerInfo").GetSection("SshHostKeyFingerprint").Value
                };
                using (Session session = new Session())
                {
                    session.Open(sessionOptions);
                    TransferOptions transferOptions = new TransferOptions();
                    transferOptions.TransferMode = TransferMode.Binary;
                    TransferOperationResult transferResult;
                    if(1==1)
                    {
                        var path = _iconfiguration.GetSection("Path_Information").GetSection("Path").Value;
                        var DestinationFolder = _iconfiguration.GetSection("Path_Information").GetSection("DestinationFolder").Value;
                        transferResult = session.PutFiles(path, DestinationFolder, false, transferOptions);
                         transferResult.Check();
                        foreach (TransferEventArgs transfer in transferResult.Transfers)
                        {
                            Console.WriteLine("upload of succeeded", transfer.FileName);
                        }
                    }
                    if(0==0)
                    {
                        var path1 = _iconfiguration.GetSection("Path_Information").GetSection("Path_Transition_tcp").Value;
                        var DestinationFolder1 = _iconfiguration.GetSection("Path_Information").GetSection("Forget_transition_tcp").Value;
                        transferResult = session.PutFiles(path1, DestinationFolder1, false, transferOptions);
                        transferResult.Check();
                        foreach (TransferEventArgs transfer in transferResult.Transfers)
                        {
                            Console.WriteLine("upload of succeeded Transition_Tcp", transfer.FileName);
                        }
                    }
                    if(2==2)
                    {
                        var path2 = _iconfiguration.GetSection("Path_Information").GetSection("Path_transition_tcp_staging").Value;
                        var DestinationFolder2 = _iconfiguration.GetSection("Path_Information").GetSection("Forget_transition_tcp_staging").Value;
                        transferResult = session.PutFiles(path2, DestinationFolder2, false, transferOptions);
                        transferResult.Check();
                        foreach (TransferEventArgs transfer in transferResult.Transfers)
                        {
                            Console.WriteLine("upload of succeeded Transition_Tcp_staging ", transfer.FileName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Error Message");
            }
        }

    }
}