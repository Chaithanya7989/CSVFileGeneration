using Coravel;
using Coravel.Scheduling.Schedule;
using CSV.CsvGeneration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace CSV
{
    public class Program
    {
        public static void Main(string[] args)
        {         
            IHost host = CreateHostBuilder(args).Build();
            host.Services.UseScheduler(Scheduler =>
            { 
                Scheduler.Schedule<CSVFileGeneration>().DailyAt(1,00).Zoned(TimeZoneInfo.Local);
                Scheduler.Schedule<SFTPTransfer>().DailyAt(1,00).Zoned(TimeZoneInfo.Local);

            }); host.Run();
            CreateHostBuilder(args).Build().Run();
        }
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddScheduler();
                    services.AddHostedService<Worker>();
                    services.AddTransient<CSVFileGeneration>();
                    services.AddTransient<SFTPTransfer>();
                    services.AddTransient<Worker>();
                });
    }
}
